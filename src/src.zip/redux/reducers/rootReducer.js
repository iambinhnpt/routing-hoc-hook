import {combineReducers} from 'redux'
import QuanLyPhimReducers from './QuanLyPhimReducer'


export default combineReducers({
    QuanLyPhimReducers
})